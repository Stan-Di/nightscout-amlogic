#!/bin/sh

export MONGO_CONNECTION="mongodb://127.0.0.1:27017/Ns$1"
(eval $(cat env/$1.env | sed 's/^/export /') && PORT=$1 node server.js $1)
